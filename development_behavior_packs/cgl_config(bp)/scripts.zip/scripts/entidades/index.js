import "@minecraft/server"

